# IcmTqsProject

Mobile application to allow users to create, choose a delivery, and track the delivery process for delivering packages for a delivery company.
The application has GPS positioning detection, QR code generation and reading, push notifications, persistence and communication with an external API with an integrated DB.

![flow](https://cdn.discordapp.com/attachments/680057808103800945/989221761793024010/unknown.png)


Admin Credentials:
user: admin@gmail.com
pass: jx3P8ByvbDQ4U4rG$

