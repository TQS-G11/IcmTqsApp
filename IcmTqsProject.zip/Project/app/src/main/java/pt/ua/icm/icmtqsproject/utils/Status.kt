package pt.ua.icm.icmtqsproject.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}