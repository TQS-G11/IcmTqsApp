package pt.ua.icm.icmtqsproject.data.model

class Rider (
    val email: String,
    val password: String,
    val Name: String,
    val citizenId: String,
)