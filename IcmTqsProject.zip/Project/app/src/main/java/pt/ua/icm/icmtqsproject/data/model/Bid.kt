package pt.ua.icm.icmtqsproject.data.model

class Bid (
    val ridersId: String,
    val deliveryId: Long,
    val distance: Double
)
