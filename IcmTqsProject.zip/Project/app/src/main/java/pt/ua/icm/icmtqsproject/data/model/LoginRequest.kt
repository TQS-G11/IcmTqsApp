package pt.ua.icm.icmtqsproject.data.model

class LoginRequest (
    val email: String,
    val password: String,
)